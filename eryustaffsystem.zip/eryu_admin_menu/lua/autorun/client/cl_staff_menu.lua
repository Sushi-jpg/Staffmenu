EryuStaffSystem = EryuStaffSystem or {}
net.Receive("StaffMenuOpenPanel", function(len)

  local EryuStaffPanel_Base = vgui.Create("DFrame")
	EryuStaffPanel_Base:SetSize(ScrW()/(1920/600),ScrH()/(1080/320))
	EryuStaffPanel_Base:Center()
	EryuStaffPanel_Base:SetTitle("")
	EryuStaffPanel_Base:SetDraggable(false)
	EryuStaffPanel_Base:MakePopup()
  EryuStaffPanel_Base:ShowCloseButton(false)
  EryuStaffPanel_Base.Paint = function(self, w, h)
    draw.RoundedBox(20,0,0,ScrW()/(1920/370),ScrH()/(1080/80), EryuStaffSystem.StaffMenu_BackgroundColor)
    draw.RoundedBox(10,0,ScrH()/(1080/50),ScrW()/(1920/530),ScrH()/(1080/270), EryuStaffSystem.StaffMenu_BackgroundColor)
    draw.SimpleText( EryuStaffSystem.StaffMenu_ServerName, "Eryu::Title_Panel", ScrW()/(1920/20),ScrH()/(1080/10), EryuStaffSystem.StaffMenu_ServerNameColor, TEXT_ALIGN_LEFT )
    draw.RoundedBox(2,ScrW()/(1920/10),ScrH()/(1080/45),ScrW()/(1920/350),ScrH()/(1080/4), EryuStaffSystem.StaffMenu_ServerNameBarColor, true, true, false, false )
  end

  local EryuStaffPanel_CloseButton = vgui.Create( "DButton", EryuStaffPanel_Base )
  EryuStaffPanel_CloseButton:SetText( "" )
  EryuStaffPanel_CloseButton:SetPos(ScrW()/(1920/495),ScrH()/(1080/55) )
  EryuStaffPanel_CloseButton:SetSize( ScrW()/(1920/30),ScrH()/(1080/34) )
  EryuStaffPanel_CloseButton.Paint = function(self, w, h)
    draw.SimpleText( "X", "Eryu::Title_Panel", ScrW()/(1920/5),ScrH()/(1080/5), Color(161, 41, 26,255), TEXT_ALIGN_LEFT )
  end
  EryuStaffPanel_CloseButton.DoClick = function()
  	EryuStaffPanel_Base:Close()
  end

  local EryuStaffPanel_StaffModButton = vgui.Create( "DButton", EryuStaffPanel_Base )
  EryuStaffPanel_StaffModButton:SetText( "" )
  EryuStaffPanel_StaffModButton:SetPos(ScrW()/(1920/40),ScrH()/(1080/85) )
  EryuStaffPanel_StaffModButton:SetSize( ScrW()/(1920/200),ScrH()/(1080/80) )
  EryuStaffPanel_StaffModButton.Paint = function(self, w, h)
    draw.RoundedBox(8,0,0,ScrW()/(1920/200),ScrH()/(1080/80), EryuStaffSystem.StaffMenuStaffMod_Color, true, true, false, false )
    draw.SimpleText( EryuStaffSystem.StaffMenuStaffMod_Name, "Eryu::Title_Panel", ScrW()/(1920/35),ScrH()/(1080/22), EryuStaffSystem.StaffMenuStaffMod_TextColor, TEXT_ALIGN_LEFT )
  end
  EryuStaffPanel_StaffModButton.DoClick = function()
    RunConsoleCommand("eryu_staffmod")
    EryuStaffPanel_Base:Close()
  end

  local EryuStaffPanel_WarningButton = vgui.Create( "DButton", EryuStaffPanel_Base )
  EryuStaffPanel_WarningButton:SetText( "" )
  EryuStaffPanel_WarningButton:SetPos(ScrW()/(1920/40),ScrH()/(1080/205) )
  EryuStaffPanel_WarningButton:SetSize( ScrW()/(1920/200),ScrH()/(1080/80) )
  EryuStaffPanel_WarningButton.Paint = function(self, w, h)
    draw.RoundedBox(8,0,0,ScrW()/(1920/200),ScrH()/(1080/80), EryuStaffSystem.StaffMenuWarn_Color, true, true, false, false )
    draw.SimpleText( EryuStaffSystem.StaffMenuWarn_Name, "Eryu::Title_Panel", ScrW()/(1920/35),ScrH()/(1080/22), EryuStaffSystem.StaffMenuWarn_TextColor, TEXT_ALIGN_LEFT )
  end
  EryuStaffPanel_WarningButton.DoClick = function()
    RunConsoleCommand("say", EryuStaffSystem.StaffMenuWarn_Command)
    EryuStaffPanel_Base:Close()
  end

  local EryuStaffPanel_UlxMenuButton = vgui.Create( "DButton", EryuStaffPanel_Base )
  EryuStaffPanel_UlxMenuButton:SetText( "" )
  EryuStaffPanel_UlxMenuButton:SetPos(ScrW()/(1920/280),ScrH()/(1080/205) )
  EryuStaffPanel_UlxMenuButton:SetSize( ScrW()/(1920/200),ScrH()/(1080/80) )
  EryuStaffPanel_UlxMenuButton.Paint = function(self, w, h)
    draw.RoundedBox(8,0,0,ScrW()/(1920/200),ScrH()/(1080/80), EryuStaffSystem.StaffMenuUlx_Color, true, true, false, false )
    draw.SimpleText( EryuStaffSystem.StaffMenuUlx_Name, "Eryu::Title_Panel", ScrW()/(1920/35),ScrH()/(1080/22), EryuStaffSystem.StaffMenuUlx_TextColor, TEXT_ALIGN_LEFT )
  end
  EryuStaffPanel_UlxMenuButton.DoClick = function()
    RunConsoleCommand("say", EryuStaffSystem.StaffMenuUlx_Command)
    EryuStaffPanel_Base:Close()
  end

  local EryuStaffPanel_LogsButton = vgui.Create( "DButton", EryuStaffPanel_Base )
  EryuStaffPanel_LogsButton:SetText( "" )
  EryuStaffPanel_LogsButton:SetPos(ScrW()/(1920/280),ScrH()/(1080/85) )
  EryuStaffPanel_LogsButton:SetSize( ScrW()/(1920/200),ScrH()/(1080/80) )

  EryuStaffPanel_LogsButton.Paint = function(self, w, h)
    draw.RoundedBox(8,0,0,ScrW()/(1920/200),ScrH()/(1080/80), EryuStaffSystem.StaffMenuLogs_Color, true, true, false, false )
    draw.SimpleText( EryuStaffSystem.StaffMenuLogs_Name, "Eryu::Title_Panel", ScrW()/(1920/35),ScrH()/(1080/22), EryuStaffSystem.StaffMenuLogs_TextColor, TEXT_ALIGN_LEFT )
  end
  EryuStaffPanel_LogsButton.DoClick = function()
    RunConsoleCommand("say", EryuStaffSystem.StaffMenuLogs_Command)
    EryuStaffPanel_Base:Close()
  end

end)
