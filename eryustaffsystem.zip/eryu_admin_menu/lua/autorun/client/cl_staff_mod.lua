local ply = LocalPlayer()
hook.Add("HUDPaint", "EryuSystemStaff:StaffMod", function()
    if EryuStaffSystem.StaffGroups[LocalPlayer():GetUserGroup()] then
        if LocalPlayer():GetNWBool("StaffMod") == true then
            for k , v in pairs(player.GetAll()) do
                local position = v:GetShootPos()
                position.z = position.z+10
                position = position:ToScreen()
                  if not position.visible then continue end

                local x, y = position.x, position.y

                  draw.DrawText(EryuStaffSystem.StaffModPoint_Symbol, "DermaLarge", x , y+20, EryuStaffSystem.StaffModPoint_Color, TEXT_ALIGN_CENTER)
                if v:GetPos():Distance(LocalPlayer():GetPos()) < 300 then
                  draw.DrawText(EryuStaffSystem.StaffMod_InfoSymbol..EryuStaffSystem.Name_Name..v:GetName(), "Eryu::Roboto_Bold", x , y-5, EryuStaffSystem.StaffMod_NameColor, TEXT_ALIGN_LEFT)
                  draw.DrawText(EryuStaffSystem.StaffMod_InfoSymbol..EryuStaffSystem.Name_Job..v:getDarkRPVar("job"), "Eryu::Roboto_Bold", x , y-35, EryuStaffSystem.StaffMod_JobColor, TEXT_ALIGN_LEFT)
                  draw.DrawText(EryuStaffSystem.StaffMod_InfoSymbol..EryuStaffSystem.Name_Health..v:Health(), "Eryu::Roboto_Bold", x , y-65, EryuStaffSystem.StaffMod_HealthColor, TEXT_ALIGN_LEFT)
                  draw.DrawText(EryuStaffSystem.StaffMod_InfoSymbol..EryuStaffSystem.Name_Armor..v:Armor(), "Eryu::Roboto_Bold", x , y-95, EryuStaffSystem.StaffMod_ArmorColor, TEXT_ALIGN_LEFT)
                  draw.DrawText(EryuStaffSystem.StaffMod_InfoSymbol..EryuStaffSystem.Name_Rank..v:GetUserGroup(), "Eryu::Roboto_Bold", x , y-125, EryuStaffSystem.StaffMod_RankColor, TEXT_ALIGN_LEFT)
                  draw.DrawText(EryuStaffSystem.StaffMod_InfoSymbol..EryuStaffSystem.Name_Money..v:getDarkRPVar("money").."$", "Eryu::Roboto_Bold", x , y-155, EryuStaffSystem.StaffMod_MoneyColor, TEXT_ALIGN_LEFT)
                end
            end
        end
    end
end)

net.Receive("StaffModCommand", function()
  if EryuStaffSystem.StaffGroups[LocalPlayer():GetUserGroup()] then
    if LocalPlayer():GetNWBool("StaffMod") == false then
      net.Start("StaffMod_On")
      net.SendToServer()
    elseif LocalPlayer():GetNWBool("StaffMod") == true then
      net.Start("StaffMod_Off")
      net.SendToServer()
    end
  end
end)
