//Languages\\
if EryuStaffSystem.Lang == "fr" then
EryuStaffSystem.Name_Money = " Argent : "
EryuStaffSystem.Name_Rank = " Grade : "
EryuStaffSystem.Name_Armor = " Armure : "
EryuStaffSystem.Name_Health = " Vie : "
EryuStaffSystem.Name_Job = " Métier : "
EryuStaffSystem.Name_Name = " Nom : "

//EN\\
elseif EryuStaffSystem.Lang == "en" then
  EryuStaffSystem.Name_Money = " Money : "
  EryuStaffSystem.Name_Rank = " Rank : "
  EryuStaffSystem.Name_Armor = " Armor : "
  EryuStaffSystem.Name_Health = " Health : "
  EryuStaffSystem.Name_Job = " Job : "
  EryuStaffSystem.Name_Name = " Name : "

end
