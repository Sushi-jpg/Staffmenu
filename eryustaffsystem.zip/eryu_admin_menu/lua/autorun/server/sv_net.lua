EryuStaffSystem = EryuStaffSystem or {}

resource.AddWorkshop( "2114846628" )

util.AddNetworkString( "StaffMenuOpenPanel" )
util.AddNetworkString( "StaffModCommand" )
util.AddNetworkString("StaffMod_On")
util.AddNetworkString("StaffMod_Off")
util.AddNetworkString("EryuOpenInGameConfigFrame")


hook.Add("PlayerSay", "Eryu::AdminModIngameConfig", function(ply, text)
  if string.lower( text ) == "!eryustaffsystem_config" then
    if EryuStaffSystem.StaffGroups[ply:GetUserGroup()] then
      net.Start("EryuOpenInGameConfigFrame")
      net.Send(ply)
      return ""
    end
  end
end)


hook.Add("PlayerSay", "Eryu:StaffMod:PlayerSay", function(ply, text)
  if string.lower( text ) == EryuStaffSystem.StaffMenuStaffMod_Command then
    if EryuStaffSystem.StaffGroups[ply:GetUserGroup()] then
      net.Start("StaffModCommand")
      net.Send(ply)
      return ""
    end
  end
end)

hook.Add("PlayerSay", "Eryu:StaffMenuPanel:PlayerSay", function(ply, text)
  if string.lower( text ) == EryuStaffSystem.StaffMenu_Command then
    if EryuStaffSystem.StaffGroups[ply:GetUserGroup()] then
      net.Start("StaffMenuOpenPanel")
      net.Send(ply)
      return ""
    end
  end
end)

net.Receive("StaffMod_On", function(len, ply)
    if EryuStaffSystem.StaffGroups[ply:GetUserGroup()] then
        ply:SetMoveType(MOVETYPE_NOCLIP)
        ply:GodEnable()
        ULib.invisible( ply, true, 0 )
        ply:SetNWBool("StaffMod", true)

    end
end)

net.Receive("StaffMod_Off", function(len, ply)
    if EryuStaffSystem.StaffGroups[ply:GetUserGroup()] then
        ply:SetMoveType(MOVETYPE_WALK)
        ply:GodDisable()
        ULib.invisible( ply, false, 0 )
        ply:SetNWBool("StaffMod", false)
    end
end)
