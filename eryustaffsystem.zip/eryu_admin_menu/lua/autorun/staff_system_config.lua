EryuStaffSystem = EryuStaffSystem or {}

--[[For the color use the color picker in Google :
https://www.google.com/search?q=color+picker&oq=color+picker&aqs=chrome.0.69i59j0l7.2048j0j7&sourceid=chrome&ie=UTF-8]]--

EryuStaffSystem.Lang = "fr" --fr, en, de, es.

EryuStaffSystem.StaffGroups = { --StaffGroup (put the ulx groups)

    ["superadmin"] = true,
    ["admin"] = true,
    ["admin-test"] = true,

}

EryuStaffSystem.UserGroups = { --UserGroup (put the ulx groups)
"user",
"vip",
}

//StaffMenu (!staffmenu)\\
EryuStaffSystem.StaffMenu_Command = "!staffmenu" --Choose the menu's command.
EryuStaffSystem.StaffMenu_BackgroundColor = Color(31, 31, 31,255) --Choose the background menu's color.
EryuStaffSystem.StaffMenu_ServerName = "Nom d'un serveur random" --Choose the menu's name at the top (23 letters max).
EryuStaffSystem.StaffMenu_ServerNameColor = Color(255,255,255,255) --Choose the name's color.
EryuStaffSystem.StaffMenu_ServerNameBarColor = Color(255,255,255,255) --choose the bar's color at the bottom of the name.

//StaffMod Button\\
EryuStaffSystem.StaffMenuStaffMod_Name = "Staff Mod" --Choose the button's name.
EryuStaffSystem.StaffMenuStaffMod_Command = "!staffmod" --Choose the button's command.
EryuStaffSystem.StaffMenuStaffMod_Color = Color(161, 41, 26,255) --Choose the button's color.
EryuStaffSystem.StaffMenuStaffMod_TextColor = Color(255,255,255,255) --Choose the text's color.

EryuStaffSystem.StaffMenuWarn_Name = "Menu Warn" --Choose the button's name.
EryuStaffSystem.StaffMenuWarn_Command = "!warn" --Choose the button's command.
EryuStaffSystem.StaffMenuWarn_Color = Color(161, 41, 26,255) --Choose the button's color.
EryuStaffSystem.StaffMenuWarn_TextColor = Color(255,255,255,255) --Choose the text's color.

EryuStaffSystem.StaffMenuUlx_Name = "Menu ULX" --Choose the button's name.
EryuStaffSystem.StaffMenuUlx_Command = "!menu" --Choose the button's command.
EryuStaffSystem.StaffMenuUlx_Color = Color(161, 41, 26,255) --Choose the button's color.
EryuStaffSystem.StaffMenuUlx_TextColor = Color(255,255,255,255) --Choose the text's color.

EryuStaffSystem.StaffMenuLogs_Name = "Menu Logs" --Choose the button's name.
EryuStaffSystem.StaffMenuLogs_Command = "!logs" --Choose the button's command.
EryuStaffSystem.StaffMenuLogs_Color = Color(161, 41, 26,255) --Choose the button's color.
EryuStaffSystem.StaffMenuLogs_TextColor = Color(255,255,255,255) --Choose the text's color.





--------------------------------------------------------------------------------


//StaffMod (!staffmod) (!staffmenu puis bouton "StaffMod")\\
EryuStaffSystem.StaffMod_OnNoclip = false --Enable the staffmod if the noclip is enable. (Default : false)

EryuStaffSystem.StaffModPoint_Symbol ="⬤" --Choose the symbol above player's head.
EryuStaffSystem.StaffModPoint_Color = Color(130,255,110,255) --Choose the symbol's color.

EryuStaffSystem.StaffMod_InfoSymbol = "•" --Choose the symbols before the information.
EryuStaffSystem.StaffMod_NameColor = Color(255,255,255,255) --Chose the color.
EryuStaffSystem.StaffMod_JobColor = Color(255,255,255,255) --Chose the color.
EryuStaffSystem.StaffMod_HealthColor = Color(255,255,255,255) --Chose the color.
EryuStaffSystem.StaffMod_ArmorColor = Color(255,255,255,255) --Chose the color.
EryuStaffSystem.StaffMod_RankColor = Color(255,255,255,255) --Chose the color.
EryuStaffSystem.StaffMod_MoneyColor = Color(255,255,255,255) --Chose the color.
